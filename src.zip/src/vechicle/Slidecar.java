package vechicle;

public class Slidecar {
    public class Car
    {
        // private (internal) constants
        private static final int MAX_DOORS = 6;
        private static final int MIN_DOORS = 1;

        // public (external) constants
        public static final String TYPE_SPORTY = "Sporty";
        public static final String TYPE_FAMILY = "Family";

        // a new property and its respective accessors
        private String carType;

        public String getCarType()
        {
            return carType;
        }
        public void setCarType(String carType)
        {
            this.carType = carType;
        }
        // rest of class the same with the exception of setNumberOfDoors
        public void setNumberOfDoors(int numberOfDoors)
        {
            //if ( MIN_DOORS >= 1 && numberOfDoors <= MAX_DOORS)
                //this.numberOfDoors = numberOfDoors;
            //else
                //this.numberOfDoors = -1;
        }
    }



}
